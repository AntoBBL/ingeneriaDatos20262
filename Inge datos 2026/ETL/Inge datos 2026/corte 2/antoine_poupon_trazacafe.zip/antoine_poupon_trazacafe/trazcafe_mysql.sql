CREATE DATABASE IF NOT EXISTS trazacafe;
USE trazacafe;

# PARTE 1 A 3

CREATE TABLE cliente (
    idCli INT PRIMARY KEY AUTO_INCREMENT,
    nombreCli VARCHAR(100) NOT NULL
);
CREATE TABLE catador (
    idCata INT PRIMARY KEY AUTO_INCREMENT,
    nombreCata VARCHAR(100) NOT NULL
);
CREATE TABLE fincas (
    idFincas INT PRIMARY KEY AUTO_INCREMENT,
    nombreFin VARCHAR(100) NOT NULL,
    caficultorRespo VARCHAR(100) NOT NULL,
    municipio VARCHAR(100) NOT NULL,
    departamento VARCHAR(100) NOT NULL,
    #altitud SMALLINT NOT NULL CHECK (altitud BETWEEN 800 AND 2500)      debia cambiar despues otra parte
    altitud SMALLINT NOT NULL,
    CONSTRAINT chk_finca_altitud CHECK (altitud BETWEEN 800 AND 2500)
);
CREATE TABLE pedido (
    idPedido INT PRIMARY KEY AUTO_INCREMENT,
    idCli INT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pendiente',
    # FOREIGN KEY (idCli) REFERENCES cliente(idCli)    cambie a causa del neuvo punto
    CONSTRAINT fk_pedido_cliente FOREIGN KEY (idCli) REFERENCES cliente(idCli)
        ON DELETE RESTRICT  -- porque no eliminan un cliente que tiene pedidos (historial)
);
CREATE TABLE lotes (
    idLote INT PRIMARY KEY AUTO_INCREMENT,
    idFincas INT NOT NULL,
    # codigo VARCHAR(20) NOT NULL UNIQUE, # cambie a causa del neuvo punto
    codigo VARCHAR(20) NOT NULL,
    variedad VARCHAR(50) NOT NULL,
    #proceso VARCHAR(10) NOT NULL,   NO buena porque no corresponde al punto 3
    proceso ENUM('lavado','honey','natural') NOT NULL,
    fechaConsecha DATE NOT NULL,
    kilos DECIMAL(7,2) NOT NULL,
    # FOREIGN KEY (idFincas) REFERENCES fincas(idFincas) # cambie a causa del neuvo punto
    CONSTRAINT uq_lotes_codigo UNIQUE (codigo),
    CONSTRAINT fk_lotes_fincas FOREIGN KEY (idFincas) REFERENCES fincas(idFincas)
        ON DELETE RESTRICT  -- req 6: no podemos eliminar una finca que tiene lotes vendidos
);
CREATE TABLE tostion (
    idTostion INT PRIMARY KEY AUTO_INCREMENT,
    loteOrigen INT NOT NULL,
    fechaTostion DATE NOT NULL,
    kilosEntra DECIMAL(7,2) NOT NULL,
    # kilosSali DECIMAL(7,2) NOT NULL CHECK (kilosSali <= kilosEntra), # cambie a causa del neuvo punto
    kilosSali DECIMAL(7,2) NOT NULL,
    #perfil VARCHAR(10) NOT NULL,   NO buena porque no corresponde al punto 3
    perfil ENUM('claro','medio','oscuro') NOT NULL,
    # FOREIGN KEY (loteOrigen) REFERENCES lotes(idLote) # cambie a causa del neuvo punto
    CONSTRAINT chk_tostion_kilos CHECK (kilosSali <= kilosEntra),
    CONSTRAINT fk_tostion_lotes FOREIGN KEY (loteOrigen) REFERENCES lotes(idLote)
        ON DELETE RESTRICT  -- garde la traçabilité: un lote tostion no debe ser eliminar
);
CREATE TABLE evaluaciones (
    idEval INT PRIMARY KEY AUTO_INCREMENT,
    idLote INT NOT NULL,
    idCata INT NOT NULL,
    # scoroSCA DECIMAL(5,2) NOT NULL CHECK (scoroSCA BETWEEN 0 AND 100), # cambie a causa del neuvo punto
    scoroSCA DECIMAL(5,2) NOT NULL,
    calificacionCafe VARCHAR(50),
    # FOREIGN KEY (idLote) REFERENCES lotes(idLote), # cambie a causa del neuvo punto
    # FOREIGN KEY (idCata) REFERENCES catador(idCata) # cambie a causa del neuvo punto
    CONSTRAINT chk_evaluaciones_score CHECK (scoroSCA BETWEEN 0 AND 100),
    CONSTRAINT fk_evaluaciones_lotes FOREIGN KEY (idLote) REFERENCES lotes(idLote)
        ON DELETE RESTRICT,
    CONSTRAINT fk_evaluaciones_catador FOREIGN KEY (idCata) REFERENCES catador(idCata)
        ON DELETE RESTRICT  -- un catador que se fue no elimina evaluaciones pasadas
);
CREATE TABLE opcionpedido (
    idOpcion INT PRIMARY KEY AUTO_INCREMENT,
    idPedido INT NOT NULL,
    idTostion INT NOT NULL,
    nbKilos DECIMAL(7,2) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    # FOREIGN KEY (idPedido) REFERENCES pedido(idPedido), # cambie a causa del neuvo punto
    # FOREIGN KEY (idTostion) REFERENCES tostion(idTostion) # cambie a causa del neuvo punto
    CONSTRAINT fk_opcionpedido_pedido FOREIGN KEY (idPedido) REFERENCES pedido(idPedido)
        ON DELETE CASCADE,  -- una linea que es raro, debe ser eliminar
    CONSTRAINT fk_opcionpedido_tostion FOREIGN KEY (idTostion) REFERENCES tostion(idTostion)
        ON DELETE RESTRICT  -- gardamos lo que hacia vendido
);

#Para intentar las restricciones (he puesto los resultados en el word evidencias)

-- intentar chk_finca_altitud
INSERT INTO fincas (nombreFin, caficultorRespo, municipio, departamento, altitud)
VALUES ('Finca Test', 'Juan Perez', 'Pitalito', 'Huila', 500);

-- intentar uq_lotes_codigo 
INSERT INTO lotes (idFincas, codigo, variedad, proceso, fechaConsecha, kilos)
VALUES (1, 'HUI-2026-014', 'Caturra', 'lavado', '2026-01-01', 100);

-- intentar chk_evaluaciones_score
INSERT INTO evaluaciones (idLote, idCata, scoroSCA) VALUES (1, 1, 150);

-- intentar chk_tostion_kilos
INSERT INTO tostion (loteOrigen, fechaTostion, kilosEntra, kilosSali, perfil)
VALUES (1, '2026-03-01', 50, 80, 'medio');

-- intentar fk_lotes_fincas 
INSERT INTO lotes (idFincas, codigo, variedad, proceso, fechaConsecha, kilos)
VALUES (9999, 'XXX-2026-999', 'Caturra', 'lavado', '2026-01-01', 10);


#parte 4
ALTER TABLE cliente
  ADD COLUMN pais VARCHAR(50) NOT NULL DEFAULT 'Colombia';

ALTER TABLE tostion
  ADD COLUMN huella_carbono_kg DECIMAL(8,2) NULL,
  ADD CONSTRAINT chk_tostion_huella CHECK (huella_carbono_kg >= 0);

ALTER TABLE lotes MODIFY COLUMN kilos DECIMAL(10,2) NOT NULL;
ALTER TABLE tostion MODIFY COLUMN kilosEntra DECIMAL(10,2) NOT NULL;
ALTER TABLE tostion MODIFY COLUMN kilosSali DECIMAL(10,2) NOT NULL;
ALTER TABLE opcionpedido MODIFY COLUMN nbKilos DECIMAL(10,2) NOT NULL;

#certificaciones N:M (una finca tiene varias certificaciones y una certificacon tiene varias fincas)
CREATE TABLE certificacion (
    idCert INT PRIMARY KEY AUTO_INCREMENT,
    nombreCert VARCHAR(50) NOT NULL
);

CREATE TABLE finca_certificacion (
    idFincas INT NOT NULL,
    idCert INT NOT NULL,
    PRIMARY KEY (idFincas, idCert),
    CONSTRAINT fk_fc_finca FOREIGN KEY (idFincas) REFERENCES fincas(idFincas)
        ON DELETE CASCADE,   # si no hay fincas, es raro sus lineas de certificaciones
    CONSTRAINT fk_fc_cert FOREIGN KEY (idCert) REFERENCES certificacion(idCert)
        ON DELETE CASCADE
);

# cambie porque la columna fue mal nombrada
ALTER TABLE pedido RENAME COLUMN status TO estado;


# Parte 5
# Fincas 
INSERT INTO fincas (nombreFin, caficultorRespo, municipio, departamento, altitud) VALUES
('Finca El Paraíso', 'Carlos Ramírez', 'Pitalito', 'Huila',1750),
('Finca La Esperanza', 'Marta Gómez', 'Salento', 'Quindío', 1900),
('Finca Buenavista', 'Luis Fernández', 'Buesaco', 'Nariño', 2100),
('Finca Los Naranjos', 'Ana Torres', 'Jardín', 'Antioquia', 1600);

# Catadores
INSERT INTO catador (nombreCata) VALUES
('Sofía Herrera'), ('Julián Rodríguez'), ('Camila Restrepo');

-- Clientes (uno en Alemania)
INSERT INTO cliente (nombreCli, pais) VALUES
('Berlin Roasters GmbH', 'Alemania'),
('Café Bogotá S.A.S.', 'Colombia'),
('Nordic Coffee House', 'Suecia');

-- Certificaciones (reto 4)
INSERT INTO certificacion (nombreCert) VALUES ('Orgánico'), ('Fair Trade');

INSERT INTO finca_certificacion (idFincas, idCert) VALUES
(1,1),(1,2),(2,1),(3,2),(4,1);

-- Lotes (8, insertion multi-lignes)
INSERT INTO lotes (idFincas, codigo, variedad, proceso, fechaConsecha, kilos) VALUES
(1,'HUI-2026-001','Caturra', 'lavado', '2026-01-15', 350.00),
(1,'HUI-2026-002','Castillo','honey', '2026-02-10', 420.50),
(2,'QUI-2026-001','Geisha', 'natural','2026-01-20', 180.00),
(2,'QUI-2026-002','Bourbon', 'lavado', '2026-03-05', 300.00),
(3,'NAR-2026-001','Caturra', 'honey', '2026-02-01', 275.00),
(3,'NAR-2026-002','Castillo','lavado', '2026-02-25', 400.00),
(4,'ANT-2026-001','Geisha', 'natural','2026-01-30', 150.00),
(4,'ANT-2026-002','Bourbon', 'honey', '2026-03-10', 320.00);

-- Evaluaciones / cataciones (10, muchos por lotes, catadores diff)
INSERT INTO evaluaciones (idLote, idCata, scoroSCA, calificacionCafe) VALUES
(4,1,82.50,'Especialidad'),
(4,2,84.00,'Especialidad'),
(5,1,78.25,'Estándar'),
(6,3,88.75,'Especialidad'),
(6,2,90.00,'Especialidad'),
(7,1,81.00,'Especialidad'),
(8,3,76.50,'Estándar'),
(9,2,85.25,'Especialidad'),
(10,3,91.50,'Especialidad'),
(11,1,79.00,'Estándar');

-- Tostiones (5)
INSERT INTO tostion (loteOrigen, fechaTostion, kilosEntra, kilosSali, perfil, huella_carbono_kg) VALUES
(4,'2026-01-20',350.00,298.00,'medio',12.50),
(6,'2026-01-25',180.00,153.00,'claro',7.20),
(7,'2026-03-10',300.00,255.00,'medio', 10.80),
(9,'2026-03-01',400.00,340.00,'oscuro',15.00),
(10,'2026-02-05',150.00,127.50,'claro', 6.00);

-- Pedidos (4)
INSERT INTO pedido (idCli, estado) VALUES
(1,'pendiente'),(2,'pendiente'),(3,'pendiente'),(1,'pendiente');

-- Lineas de pedido (7, >= 6 requeridas)
INSERT INTO opcionpedido (idPedido, idTostion, nbKilos, precio) VALUES
(1,1,50.00,45000.00),
(1,2,20.00,95000.00),
(2,3,30.00,42000.00),
(2,1,25.00,45000.00),
(3,4,40.00,38000.00),
(3,5,15.00,98000.00),
(4,2,10.00,95000.00);

-- Table lotes_especialidad (puntaje promedio >= 85)
CREATE TABLE lotes_especialidad (
    codigo_lote VARCHAR(20) NOT NULL,
    puntaje_promedio DECIMAL(5,2) NOT NULL
);

INSERT INTO lotes_especialidad (codigo_lote, puntaje_promedio)
SELECT l.codigo, AVG(e.scoroSCA)
FROM lotes l
JOIN evaluaciones e ON e.idLote = l.idLote
GROUP BY l.codigo
HAVING AVG(e.scoroSCA) >= 85;

# SELECT idLote, codigo FROM lotes;  es un test porque tenia una error a causa de valors de la tabla evaluaciones y tostion


# Parte 6
CREATE TABLE precios_referencia (
    variedad VARCHAR(50) PRIMARY KEY,
    precio_kg DECIMAL(10,2) NOT NULL,
    actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
-- Semana 1 (inserción múltiple en un solo INSERT)
INSERT INTO precios_referencia (variedad, precio_kg) VALUES
('Castillo', 32000.00),
('Caturra',35500.00),
('Geisha', 120000.00);

-- Semana 2 : upsert (MySQL 8.0.19+, syntaxe moderne avec alias)
INSERT INTO precios_referencia (variedad, precio_kg) VALUES
('Caturra',36800.00),
('Geisha',118000.00),
('Bourbon', 41000.00) AS nuevo
ON DUPLICATE KEY UPDATE
    precio_kg = nuevo.precio_kg,
    actualizado_en = NOW();
-- Verificationes (siempre para que puedo verificar porque no estuve seguro)
SELECT COUNT(*) AS total_variedades FROM precios_referencia;
SELECT * FROM precios_referencia ORDER BY variedad;


# Parte 7
SELECT COUNT(*) AS filas_a_corregir
FROM evaluaciones e
JOIN catador c ON c.idCata = e.idCata
WHERE c.nombreCata = 'Julián Rodríguez';

UPDATE evaluaciones e
JOIN catador c ON c.idCata = e.idCata
SET e.scoroSCA = GREATEST(e.scoroSCA - 1.5, 0)
WHERE c.nombreCata = 'Julián Rodríguez';

SELECT COUNT(*) AS lineas_a_descontar
FROM opcionpedido lp
JOIN pedido p ON p.idPedido = lp.idPedido
JOIN cliente cl ON cl.idCli = p.idCli
WHERE cl.pais = 'Alemania';

SET SQL_SAFE_UPDATES = 0;	#esto porque puede aparecer el error 1175, lo que estta dijo en el word 

UPDATE opcionpedido lp
JOIN pedido p ON p.idPedido = lp.idPedido
JOIN cliente cl ON cl.idCli = p.idCli
SET lp.precio = lp.precio * 0.90
WHERE cl.pais = 'Alemania';

SET SQL_SAFE_UPDATES = 1;


# Parte 8
DELETE FROM fincas WHERE nombreFin = 'Finca El Paraíso';  #hubo una error y yo la ponia en el word 

ALTER TABLE fincas
    ADD COLUMN activa BOOLEAN NOT NULL DEFAULT TRUE;

UPDATE fincas
SET activa = FALSE
WHERE nombreFin = 'Finca El Paraíso'; # es normal que hay un error porque es para evitar que update o delete sin clave

# para verificacion
SELECT nombreFin, caficultorRespo, activa FROM fincas;

INSERT INTO evaluaciones (idLote, idCata, scoroSCA, calificacionCafe)
SELECT l.idLote, c.idCata, 70.00, 'Prueba'
FROM lotes l
JOIN catador c ON c.nombreCata = 'Sofía Herrera'
WHERE l.codigo = 'HUI-2026-014';

DELETE ev
FROM evaluaciones ev
JOIN lotes l ON l.idLote = ev.idLote
WHERE l.codigo = 'HUI-2026-014';

TRUNCATE TABLE lotes_especialidad;
DROP TABLE lotes_especialidad;


# Parte 9
SET SQL_SAFE_UPDATES = 0;	# porque tenia el problema
-- 1)
ALTER TABLE tostion
    ADD COLUMN kilosDisponibles DECIMAL(10,2) NOT NULL DEFAULT 0,
    ADD CONSTRAINT chk_tostion_disponibles CHECK (kilosDisponibles >= 0);

UPDATE tostion t
SET t.kilosDisponibles = t.kilosSali - COALESCE(
    (SELECT SUM(op.nbKilos) FROM opcionpedido op WHERE op.idTostion = t.idTostion), 0
);

SELECT idTostion, loteOrigen, kilosSali, kilosDisponibles FROM tostion;

-- 2) 
START TRANSACTION;

INSERT INTO pedido (idCli, estado)
SELECT idCli, 'pendiente' FROM cliente WHERE nombreCli = 'Café Bogotá S.A.S.';
SET @idPedidoOk = LAST_INSERT_ID();

INSERT INTO opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT @idPedidoOk, t.idTostion, 20.00, 42000.00
FROM tostion t JOIN lotes l ON l.idLote = t.loteOrigen
WHERE l.codigo = 'HUI-2026-001';

INSERT INTO opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT @idPedidoOk, t.idTostion, 15.00, 42000.00
FROM tostion t JOIN lotes l ON l.idLote = t.loteOrigen
WHERE l.codigo = 'QUI-2026-002';

UPDATE tostion t JOIN lotes l ON l.idLote = t.loteOrigen
SET t.kilosDisponibles = t.kilosDisponibles - 20.00
WHERE l.codigo = 'HUI-2026-001';

UPDATE tostion t JOIN lotes l ON l.idLote = t.loteOrigen
SET t.kilosDisponibles = t.kilosDisponibles - 15.00
WHERE l.codigo = 'QUI-2026-002';

COMMIT;

SELECT * FROM pedido WHERE idPedido = @idPedidoOk;
SELECT * FROM opcionpedido WHERE idPedido = @idPedidoOk;

-- 3) 
START TRANSACTION;

INSERT INTO pedido (idCli, estado)
SELECT idCli, 'pendiente' FROM cliente WHERE nombreCli = 'Nordic Coffee House';
SET @idPedidoFail = LAST_INSERT_ID();

INSERT INTO opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT @idPedidoFail, t.idTostion, 9999.00, 42000.00
FROM tostion t JOIN lotes l ON l.idLote = t.loteOrigen
WHERE l.codigo = 'HUI-2026-001';

UPDATE tostion t JOIN lotes l ON l.idLote = t.loteOrigen
SET t.kilosDisponibles = t.kilosDisponibles - 9999.00
WHERE l.codigo = 'HUI-2026-001';		# he escribi la error en el word

ROLLBACK;

SELECT * FROM pedido WHERE idPedido = @idPedidoFail;  

-- 4) 
START TRANSACTION;

INSERT INTO pedido (idCli, estado)
SELECT idCli, 'pendiente' FROM cliente WHERE nombreCli = 'Nordic Coffee House';
SET @idPedidoSp = LAST_INSERT_ID();

INSERT INTO opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT @idPedidoSp, t.idTostion, 10.00, 38000.00
FROM tostion t JOIN lotes l ON l.idLote = t.loteOrigen
WHERE l.codigo = 'NAR-2026-002';

UPDATE tostion t JOIN lotes l ON l.idLote = t.loteOrigen
SET t.kilosDisponibles = t.kilosDisponibles - 10.00
WHERE l.codigo = 'NAR-2026-002';

SAVEPOINT antes_segunda_linea;

INSERT INTO opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT @idPedidoSp, t.idTostion, 5.00, 98000.00
FROM tostion t JOIN lotes l ON l.idLote = t.loteOrigen
WHERE l.codigo = 'ANT-2026-001';

UPDATE tostion t JOIN lotes l ON l.idLote = t.loteOrigen
SET t.kilosDisponibles = t.kilosDisponibles - 5.00
WHERE l.codigo = 'ANT-2026-001';

ROLLBACK TO SAVEPOINT antes_segunda_linea;
COMMIT;

SELECT * FROM opcionpedido WHERE idPedido = @idPedidoSp;  -- solo 1 linea

-- 5) 
START TRANSACTION;
CREATE TABLE prueba (id INT);
ROLLBACK;

SHOW TABLES LIKE 'prueba';

SET SQL_SAFE_UPDATES = 1;

# Parte 10

DROP VIEW IF EXISTS v_trazabilidad;

CREATE OR REPLACE VIEW v_trazabilidad AS
SELECT
    op.idOpcion,
    op.idPedido,
    cl.nombreCli AS cliente,
    cl.pais AS pais_cliente,
    f.nombreFin AS finca,
    f.caficultorRespo AS caficultor,
    f.municipio,
    f.altitud,
    l.variedad,
    l.proceso,
    ev.puntaje_promedio,
    t.fechaTostion,
    t.perfil,
    cert.certificaciones,
    CONCAT(
        l.variedad, ' ', l.proceso, ' de ', f.nombreFin, ', ', f.municipio,
        ' (', REPLACE(FORMAT(f.altitud,0),',','.'), ' m). ',
        'Puntaje ', REPLACE(FORMAT(ev.puntaje_promedio,2),'.',','), '. ',
        'Tostado ', t.perfil, ' el ', DATE_FORMAT(t.fechaTostion,'%Y-%m-%d'), '.',
        IFNULL(CONCAT(' Certificaciones: ', cert.certificaciones, '.'), '')
    ) AS texto_qr
FROM opcionpedido op
JOIN pedido p ON p.idPedido = op.idPedido
JOIN cliente cl ON cl.idCli = p.idCli
JOIN tostion t ON t.idTostion = op.idTostion
JOIN lotes l ON l.idLote = t.loteOrigen
JOIN fincas f ON f.idFincas = l.idFincas
JOIN (
    SELECT idLote, AVG(scoroSCA) AS puntaje_promedio
    FROM evaluaciones
    GROUP BY idLote
) ev ON ev.idLote = l.idLote
LEFT JOIN (
    SELECT fc.idFincas, GROUP_CONCAT(c.nombreCert SEPARATOR ', ') AS certificaciones
    FROM finca_certificacion fc
    JOIN certificacion c ON c.idCert = fc.idCert
    GROUP BY fc.idFincas
) cert ON cert.idFincas = f.idFincas;

-- Consulta filtrando un solo pedido (como hacera la app)
SELECT idPedido FROM pedido p
JOIN cliente c ON c.idCli = p.idCli
WHERE c.nombreCli = 'Café Bogotá S.A.S.'
LIMIT 1;

SELECT * FROM v_trazabilidad WHERE idPedido = 1;