SELECT 'CREATE DATABASE trazacafe'

CREATE SCHEMA operacion;	-- es casi el mismo codigo que en sql a la differencia que la escritura es differente
							-- asi que las cosas son la adaptacion de lo que he hecho en mysql workbench
-- Parte 1 a 3 :						
CREATE TABLE operacion.cliente (
    idCli INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombreCli VARCHAR(100) NOT NULL
);
CREATE TABLE operacion.catador (
    idCata INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombreCata VARCHAR(100) NOT NULL
);
CREATE TABLE operacion.fincas (
    idFincas INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombreFin VARCHAR(100) NOT NULL,
    caficultorRespo VARCHAR(100) NOT NULL,
    municipio VARCHAR(100) NOT NULL,
    departamento VARCHAR(100) NOT NULL,
    -- altitud SMALLINT NOT NULL CHECK (altitud BETWEEN 800 AND 2500) -- cambie a causa del neuvo punto
    altitud  SMALLINT NOT NULL,
    CONSTRAINT chk_finca_altitud CHECK (altitud BETWEEN 800 AND 2500)
);
CREATE TABLE operacion.pedido (
    idPedido INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idCli INT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pendiente',
    -- FOREIGN KEY (idCli) REFERENCES operacion.cliente(idCli) -- cambie a causa del neuvo punto
    CONSTRAINT fk_pedido_cliente FOREIGN KEY (idCli) REFERENCES operacion.cliente(idCli)
        ON DELETE RESTRICT
);
CREATE TABLE operacion.lotes (
    idLote INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idFincas INT NOT NULL,
    -- codigo VARCHAR(20) NOT NULL UNIQUE, -- cambie a causa del neuvo punto
    codigo VARCHAR(20) NOT NULL,
    variedad VARCHAR(50) NOT NULL,
    -- proceso VARCHAR(10) NOT NULL CHECK (proceso IN ('lavado','honey','natural')), -- cambie a causa del neuvo punto
    proceso VARCHAR(10) NOT NULL,
    fechaConsecha DATE NOT NULL,
    kilos NUMERIC(7,2) NOT NULL,
    -- FOREIGN KEY (idFincas) REFERENCES operacion.fincas(idFincas) -- cambie a causa del neuvo punto
    CONSTRAINT uq_lotes_codigo UNIQUE (codigo),
    CONSTRAINT chk_lotes_proceso CHECK (proceso IN ('lavado','honey','natural')),
    CONSTRAINT fk_lotes_fincas FOREIGN KEY (idFincas) REFERENCES operacion.fincas(idFincas)
        ON DELETE RESTRICT
);
CREATE TABLE operacion.tostion (
    idTostion INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    loteOrigen INT NOT NULL,
    fechaTostion DATE NOT NULL,
    kilosEntra NUMERIC(7,2) NOT NULL,
    -- kilosSali NUMERIC(7,2) NOT NULL CHECK (kilosSali <= kilosEntra), -- cambie a causa del neuvo punto
    kilosSali NUMERIC(7,2) NOT NULL,
    -- perfil VARCHAR(10) NOT NULL CHECK (perfil IN ('claro','medio','oscuro')), -- cambie a causa del neuvo punto
    perfil VARCHAR(10) NOT NULL,
    -- FOREIGN KEY (loteOrigen) REFERENCES operacion.lotes(idLote) -- cambie a causa del neuvo punto
    CONSTRAINT chk_tostion_kilos CHECK (kilosSali <= kilosEntra),
    CONSTRAINT chk_tostion_perfil CHECK (perfil IN ('claro','medio','oscuro')),
    CONSTRAINT fk_tostion_lotes FOREIGN KEY (loteOrigen) REFERENCES operacion.lotes(idLote)
        ON DELETE RESTRICT
);
CREATE TABLE operacion.evaluaciones (
    idEval INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idLote INT NOT NULL,
    idCata INT NOT NULL,
    -- scoroSCA NUMERIC(5,2) NOT NULL CHECK (scoroSCA BETWEEN 0 AND 100), -- cambie a causa del neuvo punto
    scoroSCA NUMERIC(5,2) NOT NULL,
    calificacionCafe VARCHAR(50),
    -- FOREIGN KEY (idLote) REFERENCES operacion.lotes(idLote), -- cambie a causa del neuvo punto
    -- FOREIGN KEY (idCata) REFERENCES operacion.catador(idCata) -- cambie a causa del neuvo punto
    CONSTRAINT chk_evaluaciones_score CHECK (scoroSCA BETWEEN 0 AND 100),
    CONSTRAINT fk_evaluaciones_lotes FOREIGN KEY (idLote) REFERENCES operacion.lotes(idLote)
        ON DELETE RESTRICT,
    CONSTRAINT fk_evaluaciones_catador FOREIGN KEY (idCata) REFERENCES operacion.catador(idCata)
        ON DELETE RESTRICT
);
CREATE TABLE operacion.opcionpedido (
    idOpcion INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    idPedido INT NOT NULL,
    idTostion INT NOT NULL,
    nbKilos NUMERIC(7,2) NOT NULL,
    precio NUMERIC(10,2) NOT NULL,
    -- FOREIGN KEY (idPedido) REFERENCES operacion.pedido(idPedido), -- cambie a causa del neuvo punto
    -- FOREIGN KEY (idTostion) REFERENCES operacion.tostion(idTostion) -- cambie a causa del neuvo punto
    CONSTRAINT fk_opcionpedido_pedido FOREIGN KEY (idPedido) REFERENCES operacion.pedido(idPedido)
        ON DELETE CASCADE,
    CONSTRAINT fk_opcionpedido_tostion FOREIGN KEY (idTostion) REFERENCES operacion.tostion(idTostion)
        ON DELETE RESTRICT
);
-- hubo una error de execucion, despues comprendi que debemos alter table cada elecciones :

-- 1. Fincas
ALTER TABLE operacion.fincas 
    ADD CONSTRAINT chk_finca_altitud CHECK (altitud BETWEEN 800 AND 2500);

-- 2. Pedido
ALTER TABLE operacion.pedido 
    ADD CONSTRAINT fk_pedido_cliente FOREIGN KEY (idCli) REFERENCES operacion.cliente(idCli) ON DELETE RESTRICT;

-- 3. Lotes
ALTER TABLE operacion.lotes 
    ADD CONSTRAINT uq_lotes_codigo UNIQUE (codigo),
    ADD CONSTRAINT chk_lotes_proceso CHECK (proceso IN ('lavado','honey','natural')),
    ADD CONSTRAINT fk_lotes_fincas FOREIGN KEY (idFincas) REFERENCES operacion.fincas(idFincas) ON DELETE RESTRICT;

-- 4. Tostion
ALTER TABLE operacion.tostion 
    ADD CONSTRAINT chk_tostion_kilos CHECK (kilosSali <= kilosEntra),
    ADD CONSTRAINT chk_tostion_perfil CHECK (perfil IN ('claro','medio','oscuro')),
    ADD CONSTRAINT fk_tostion_lotes FOREIGN KEY (loteOrigen) REFERENCES operacion.lotes(idLote) ON DELETE RESTRICT;

-- 5. Evaluaciones
ALTER TABLE operacion.evaluaciones 
    ADD CONSTRAINT chk_evaluaciones_score CHECK (scoroSCA BETWEEN 0 AND 100),
    ADD CONSTRAINT fk_evaluaciones_lotes FOREIGN KEY (idLote) REFERENCES operacion.lotes(idLote) ON DELETE RESTRICT,
    ADD CONSTRAINT fk_evaluaciones_catador FOREIGN KEY (idCata) REFERENCES operacion.catador(idCata) ON DELETE RESTRICT;

-- 6. Opcionpedido
ALTER TABLE operacion.opcionpedido 
    ADD CONSTRAINT fk_opcionpedido_pedido FOREIGN KEY (idPedido) REFERENCES operacion.pedido(idPedido) ON DELETE CASCADE,
    ADD CONSTRAINT fk_opcionpedido_tostion FOREIGN KEY (idTostion) REFERENCES operacion.tostion(idTostion) ON DELETE RESTRICT;

-- Para intentar las restricciones :

-- 1. intentar chk_finca_altitud
INSERT INTO operacion.fincas (nombreFin, caficultorRespo, municipio, departamento, altitud)
VALUES ('Finca Test', 'Juan Perez', 'Pitalito', 'Huila', 500);


-- 2. intentar uq_lotes_codigo
-- etape A 
INSERT INTO operacion.fincas (nombreFin, caficultorRespo, municipio, departamento, altitud)
VALUES ('Finca Valida', 'Carlos', 'Pitalito', 'Huila', 1500);

-- etape B *2
INSERT INTO operacion.lotes (idFincas, codigo, variedad, proceso, fechaConsecha, kilos)
VALUES (1, 'HUI-2026-014', 'Caturra', 'lavado', '2026-01-01', 100);

INSERT INTO operacion.lotes (idFincas, codigo, variedad, proceso, fechaConsecha, kilos)
VALUES (1, 'HUI-2026-014', 'Bourbon', 'honey', '2026-02-01', 50);

-- 3. intentar chk_evaluaciones_score
INSERT INTO operacion.evaluaciones (idLote, idCata, scoroSCA) 
VALUES (1, 1, 150);

-- 4. intentar chk_tostion_kilos
INSERT INTO operacion.tostion (loteOrigen, fechaTostion, kilosEntra, kilosSali, perfil)
VALUES (1, '2026-03-01', 50, 80, 'medio');

-- 5. intentar fk_lotes_fincas (référence à une finca inexistante)
INSERT INTO operacion.lotes (idFincas, codigo, variedad, proceso, fechaConsecha, kilos)
VALUES (9999, 'XXX-2026-999', 'Caturra', 'lavado', '2026-01-01', 10);


-- Parte 4 :
ALTER TABLE operacion.cliente
  ADD COLUMN pais VARCHAR(50) NOT NULL DEFAULT 'Colombia';
  
ALTER TABLE operacion.tostion
  ADD COLUMN huella_carbono_kg NUMERIC(8,2) NULL,
  ADD CONSTRAINT chk_tostion_huella CHECK (huella_carbono_kg >= 0);

ALTER TABLE operacion.lotes        ALTER COLUMN kilos      TYPE NUMERIC(10,2);
ALTER TABLE operacion.tostion      ALTER COLUMN kilosEntra TYPE NUMERIC(10,2);
ALTER TABLE operacion.tostion      ALTER COLUMN kilosSali  TYPE NUMERIC(10,2);
ALTER TABLE operacion.opcionpedido ALTER COLUMN nbKilos    TYPE NUMERIC(10,2);

--  certificaciones
CREATE TABLE operacion.certificacion (
    idCert INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nombreCert  VARCHAR(50) NOT NULL
);
CREATE TABLE operacion.finca_certificacion (
    idFincas INT NOT NULL,
    idCert INT NOT NULL,
    PRIMARY KEY (idFincas, idCert),
    CONSTRAINT fk_fc_finca FOREIGN KEY (idFincas) REFERENCES operacion.fincas(idFincas)
        ON DELETE CASCADE,
    CONSTRAINT fk_fc_cert FOREIGN KEY (idCert) REFERENCES operacion.certificacion(idCert)
        ON DELETE CASCADE
);

--  renombrar columna mal nombrada
ALTER TABLE operacion.pedido RENAME COLUMN status TO estado;


-- Parte 5
INSERT INTO operacion.fincas (nombreFin, caficultorRespo, municipio, departamento, altitud) VALUES
('Finca El Paraíso','Carlos Ramírez','Pitalito','Huila', 1750),
('Finca La Esperanza','Marta Gómez','Salento', 'Quindío',1900),
('Finca Buenavista', 'Luis Fernández','Buesaco', 'Nariño', 2100),
('Finca Los Naranjos','Ana Torres','Jardín', 'Antioquia',1600);

INSERT INTO operacion.catador (nombreCata) VALUES
('Sofía Herrera'), ('Julián Rodríguez'), ('Camila Restrepo');

INSERT INTO operacion.cliente (nombreCli, pais) VALUES
('Berlin Roasters GmbH','Alemania'),
('Café Bogotá S.A.S.','Colombia'),
('Nordic Coffee House','Suecia');

INSERT INTO operacion.certificacion (nombreCert) VALUES ('Orgánico'), ('Fair Trade');

INSERT INTO operacion.finca_certificacion (idFincas, idCert) VALUES
(7,5),(7,6),(8,5),(9,6),(10,5);

INSERT INTO operacion.lotes (idFincas, codigo, variedad, proceso, fechaConsecha, kilos) VALUES
(7,'HUI-2026-001','Caturra', 'lavado', '2026-01-15', 350.00),
(7,'HUI-2026-002','Castillo','honey',  '2026-02-10', 420.50),
(8,'QUI-2026-001','Geisha',  'natural','2026-01-20', 180.00),
(8,'QUI-2026-002','Bourbon', 'lavado', '2026-03-05', 300.00),
(9,'NAR-2026-001','Caturra', 'honey',  '2026-02-01', 275.00),
(9,'NAR-2026-002','Castillo','lavado', '2026-02-25', 400.00),
(10,'ANT-2026-001','Geisha',  'natural','2026-01-30', 150.00),
(10,'ANT-2026-002','Bourbon', 'honey',  '2026-03-10', 320.00);

-- Evaluaciones 
INSERT INTO operacion.evaluaciones (idLote, idCata, scoroSCA, calificacionCafe)
SELECT l.idLote, v.idCata, v.scoroSCA, v.calificacionCafe
FROM operacion.lotes l
JOIN (VALUES
    ('HUI-2026-001',4,82.50,'Especialidad'),
    ('HUI-2026-001',5,84.00,'Especialidad'),
    ('HUI-2026-002',4,78.25,'Estándar'),
    ('QUI-2026-001',6,88.75,'Especialidad'),
    ('QUI-2026-001',5,90.00,'Especialidad'),
    ('QUI-2026-002',4,81.00,'Especialidad'),
    ('NAR-2026-001',6,76.50,'Estándar'),
    ('NAR-2026-002',5,85.25,'Especialidad'),
    ('ANT-2026-001',6,91.50,'Especialidad'),
    ('ANT-2026-002',4,79.00,'Estándar')
) AS v(codigo, idCata, scoroSCA, calificacionCafe)
ON l.codigo = v.codigo;

-- Tostiones 
INSERT INTO operacion.tostion (loteOrigen, fechaTostion, kilosEntra, kilosSali, perfil, huella_carbono_kg)
SELECT l.idLote, v.fechaTostion, v.kilosEntra, v.kilosSali, v.perfil, v.huella
FROM operacion.lotes l
JOIN (VALUES
    ('HUI-2026-001','2026-01-20'::date,350.00,298.00,'medio',12.50),
    ('QUI-2026-001','2026-01-25'::date,180.00,153.00,'claro',7.20),
    ('QUI-2026-002','2026-03-10'::date,300.00,255.00,'medio',10.80),
    ('NAR-2026-002','2026-03-01'::date,400.00,340.00,'oscuro',15.00),
    ('ANT-2026-001','2026-02-05'::date,150.00,127.50,'claro',6.00)
) AS v(codigo, fechaTostion, kilosEntra, kilosSali, perfil, huella)
ON l.codigo = v.codigo;

INSERT INTO operacion.pedido (idCli, estado)
SELECT c.idCli, v.estado
FROM operacion.cliente c
JOIN (VALUES
    ('Berlin Roasters GmbH', 'pendiente'),
    ('Café Bogotá S.A.S.',   'pendiente'),
    ('Nordic Coffee House',  'pendiente'),
    ('Berlin Roasters GmbH', 'pendiente')
) AS v(nombreCli, estado)
ON c.nombreCli = v.nombreCli;

INSERT INTO operacion.opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT v.idPedido, t.idTostion, v.nbKilos, v.precio
FROM operacion.tostion t
JOIN operacion.lotes l ON l.idLote = t.loteOrigen
JOIN (VALUES
    (9,'HUI-2026-001',50.00,45000.00),
    (9,'HUI-2026-002',20.00, 95000.00),
    (11,'QUI-2026-002', 30.00,42000.00),
    (11,'HUI-2026-001',25.00, 45000.00),
    (12,'NAR-2026-002',40.00,38000.00),
    (12,'ANT-2026-001', 15.00, 98000.00),
    (10,'HUI-2026-002',10.00, 95000.00)
) AS v(idPedido, codigo, nbKilos, precio)
ON v.codigo = l.codigo;

CREATE TABLE operacion.lotes_especialidad (
    codigo_lote      VARCHAR(20) NOT NULL,
    puntaje_promedio NUMERIC(5,2) NOT NULL
);

INSERT INTO operacion.lotes_especialidad (codigo_lote, puntaje_promedio)
SELECT l.codigo, AVG(e.scoroSCA)
FROM operacion.lotes l
JOIN operacion.evaluaciones e ON e.idLote = l.idLote
GROUP BY l.codigo
HAVING AVG(e.scoroSCA) >= 85;


-- Parte 6
CREATE TABLE operacion.precios_referencia (
    variedad VARCHAR(50) PRIMARY KEY,
    precio_kg NUMERIC(10,2) NOT NULL,
    actualizado_en TIMESTAMP NOT NULL DEFAULT NOW()
);
-- Semana 1 (inserción múltiple en un solo INSERT)
INSERT INTO operacion.precios_referencia (variedad, precio_kg) VALUES
('Castillo', 32000.00),
('Caturra',35500.00),
('Geisha', 120000.00);

-- Semana 2 : upsert
INSERT INTO operacion.precios_referencia (variedad, precio_kg) VALUES
('Caturra',36800.00),
('Geisha',118000.00),
('Bourbon',41000.00)
ON CONFLICT (variedad)
DO UPDATE SET
    precio_kg = EXCLUDED.precio_kg,
    actualizado_en = NOW();

-- Vercificaciones :
SELECT COUNT(*) AS total_variedades FROM operacion.precios_referencia;
SELECT * FROM operacion.precios_referencia ORDER BY variedad;


-- Parte 7
SELECT COUNT(*) AS filas_a_corregir
FROM operacion.evaluaciones e
JOIN operacion.catador c ON c.idCata = e.idCata
WHERE c.nombreCata = 'Julián Rodríguez';

UPDATE operacion.evaluaciones e
SET scoroSCA = GREATEST(e.scoroSCA - 1.5, 0)
FROM operacion.catador c
WHERE c.idCata = e.idCata
  AND c.nombreCata = 'Julián Rodríguez';

SELECT COUNT(*) AS lineas_a_descontar
FROM operacion.opcionpedido lp
JOIN operacion.pedido p ON p.idPedido = lp.idPedido
JOIN operacion.cliente cl ON cl.idCli = p.idCli
WHERE cl.pais = 'Alemania';

UPDATE operacion.opcionpedido lp
SET precio = lp.precio * 0.90
FROM operacion.pedido p
JOIN operacion.cliente cl ON cl.idCli = p.idCli
WHERE p.idPedido = lp.idPedido
  AND cl.pais = 'Alemania';


-- Parte 8
DELETE FROM operacion.fincas WHERE nombreFin = 'Finca El Paraíso';

ALTER TABLE operacion.fincas
    ADD COLUMN activa BOOLEAN NOT NULL DEFAULT TRUE;

UPDATE operacion.fincas
SET activa = FALSE
WHERE nombreFin = 'Finca El Paraíso';

SELECT nombreFin, caficultorRespo, activa FROM operacion.fincas;

INSERT INTO operacion.evaluaciones (idLote, idCata, scoroSCA, calificacionCafe)
SELECT l.idLote, c.idCata, 70.00, 'Prueba'
FROM operacion.lotes l
JOIN operacion.catador c ON c.nombreCata = 'Sofía Herrera'
WHERE l.codigo = 'HUI-2026-014';

DELETE FROM operacion.evaluaciones ev
USING operacion.lotes l
WHERE l.idLote = ev.idLote
  AND l.codigo = 'HUI-2026-014';

TRUNCATE TABLE operacion.lotes_especialidad;
DROP TABLE operacion.lotes_especialidad;


-- Parte 9
-- 1) 
ALTER TABLE operacion.tostion
    ADD COLUMN kilosDisponibles NUMERIC(10,2) NOT NULL DEFAULT 0,
    ADD CONSTRAINT chk_tostion_disponibles CHECK (kilosDisponibles >= 0);

UPDATE operacion.tostion t
SET kilosDisponibles = t.kilosSali - COALESCE(
    (SELECT SUM(op.nbKilos) FROM operacion.opcionpedido op WHERE op.idTostion = t.idTostion), 0
);

SELECT idTostion, loteOrigen, kilosSali, kilosDisponibles FROM operacion.tostion;

-- 2) Transaccion 
BEGIN;

INSERT INTO operacion.pedido (idCli, estado)
SELECT idCli, 'pendiente' FROM operacion.cliente WHERE nombreCli = 'Café Bogotá S.A.S.'
RETURNING idPedido;  

INSERT INTO operacion.opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT 13, t.idTostion, 20.00, 42000.00
FROM operacion.tostion t JOIN operacion.lotes l ON l.idLote = t.loteOrigen
WHERE l.codigo = 'HUI-2026-001';

INSERT INTO operacion.opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT 13, t.idTostion, 15.00, 42000.00
FROM operacion.tostion t JOIN operacion.lotes l ON l.idLote = t.loteOrigen
WHERE l.codigo = 'QUI-2026-002';

UPDATE operacion.tostion t
SET kilosDisponibles = kilosDisponibles - 20.00
FROM operacion.lotes l
WHERE l.idLote = t.loteOrigen AND l.codigo = 'HUI-2026-001';

UPDATE operacion.tostion t
SET kilosDisponibles = kilosDisponibles - 15.00
FROM operacion.lotes l
WHERE l.idLote = t.loteOrigen AND l.codigo = 'QUI-2026-002';

COMMIT;

SELECT * FROM operacion.pedido WHERE idPedido = 13;
SELECT * FROM operacion.opcionpedido WHERE idPedido = 13;

-- 3) 
BEGIN;

INSERT INTO operacion.pedido (idCli, estado)
SELECT idCli, 'pendiente' FROM operacion.cliente WHERE nombreCli = 'Nordic Coffee House'
RETURNING idPedido;  

INSERT INTO operacion.opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT 14, t.idTostion, 9999.00, 42000.00
FROM operacion.tostion t JOIN operacion.lotes l ON l.idLote = t.loteOrigen
WHERE l.codigo = 'HUI-2026-001';

UPDATE operacion.tostion t
SET kilosDisponibles = kilosDisponibles - 9999.00
FROM operacion.lotes l
WHERE l.idLote = t.loteOrigen AND l.codigo = 'HUI-2026-001';
--pb que escribi en el word 

ROLLBACK;

SELECT * FROM operacion.pedido WHERE idPedido = 14;  -- vacio que no quedo ni la cabecera

-- 4) 
BEGIN;

INSERT INTO operacion.pedido (idCli, estado)
SELECT idCli, 'pendiente' FROM operacion.cliente WHERE nombreCli = 'Nordic Coffee House'
RETURNING idPedido; -- pb

INSERT INTO operacion.opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT 15, t.idTostion, 10.00, 38000.00
FROM operacion.tostion t JOIN operacion.lotes l ON l.idLote = t.loteOrigen
WHERE l.codigo = 'NAR-2026-002';

UPDATE operacion.tostion t
SET kilosDisponibles = kilosDisponibles - 10.00
FROM operacion.lotes l
WHERE l.idLote = t.loteOrigen AND l.codigo = 'NAR-2026-002';

SAVEPOINT antes_segunda_linea;

INSERT INTO operacion.opcionpedido (idPedido, idTostion, nbKilos, precio)
SELECT 15, t.idTostion, 5.00, 98000.00
FROM operacion.tostion t JOIN operacion.lotes l ON l.idLote = t.loteOrigen
WHERE l.codigo = 'ANT-2026-001';

UPDATE operacion.tostion t
SET kilosDisponibles = kilosDisponibles - 5.00
FROM operacion.lotes l
WHERE l.idLote = t.loteOrigen AND l.codigo = 'ANT-2026-001';

ROLLBACK TO SAVEPOINT antes_segunda_linea;
COMMIT;

SELECT * FROM operacion.opcionpedido WHERE idPedido = 15;  -- solo 1 línea

-- 5)
ROLLBACK;
BEGIN;
CREATE TABLE operacion.prueba (id INT);
ROLLBACK;

SELECT * FROM information_schema.tables
WHERE table_schema = 'operacion' AND table_name = 'prueba';  

-- Parte 10
ROLLBACK;
DROP VIEW IF EXISTS operacion.v_trazabilidad;

CREATE OR REPLACE VIEW operacion.v_trazabilidad AS
SELECT
    op.idOpcion,
    op.idPedido,
    cl.nombreCli AS cliente,
    cl.pais AS pais_cliente,
    f.nombreFin AS finca,
    f.caficultorRespo AS caficultor,
    f.municipio,
    f.altitud,
    l.variedad,
    l.proceso,
    ev.puntaje_promedio,
    t.fechaTostion,
    t.perfil,
    cert.certificaciones,
    l.variedad || ' ' || l.proceso || ' de ' || f.nombreFin || ', ' || f.municipio
        || ' (' || REPLACE(to_char(f.altitud, 'FM999G999'), ',', '.') || ' m). '
        || 'Puntaje ' || REPLACE(to_char(ev.puntaje_promedio, 'FM990.00'), '.', ',') || '. '
        || 'Tostado ' || t.perfil || ' el ' || to_char(t.fechaTostion, 'YYYY-MM-DD') || '.'
        || COALESCE(' Certificaciones: ' || cert.certificaciones || '.', '') AS texto_qr
FROM operacion.opcionpedido op
JOIN operacion.pedido p ON p.idPedido = op.idPedido
JOIN operacion.cliente cl ON cl.idCli = p.idCli
JOIN operacion.tostion t ON t.idTostion = op.idTostion
JOIN operacion.lotes l ON l.idLote = t.loteOrigen
JOIN operacion.fincas f ON f.idFincas = l.idFincas
JOIN (
    SELECT idLote, AVG(scoroSCA) AS puntaje_promedio
    FROM operacion.evaluaciones
    GROUP BY idLote
) ev ON ev.idLote = l.idLote
LEFT JOIN (
    SELECT fc.idFincas, STRING_AGG(c.nombreCert, ', ') AS certificaciones
    FROM operacion.finca_certificacion fc
    JOIN operacion.certificacion c ON c.idCert = fc.idCert
    GROUP BY fc.idFincas
) cert ON cert.idFincas = f.idFincas;

-- Consulta filtrando un solo pedido
SELECT idPedido FROM operacion.pedido p
JOIN operacion.cliente c ON c.idCli = p.idCli
WHERE c.nombreCli = 'Café Bogotá S.A.S.'
LIMIT 1;


SELECT * FROM operacion.v_trazabilidad WHERE idPedido = 11;