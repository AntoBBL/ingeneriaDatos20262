CREATE DATABASE IF NOT EXISTS biblioteca_db;
USE biblioteca_db;

CREATE TABLE socios (
  id     INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  email  VARCHAR(100) NOT NULL UNIQUE,
  activo BOOLEAN      NOT NULL DEFAULT TRUE
);

CREATE TABLE libros (
  id                     INT AUTO_INCREMENT PRIMARY KEY,
  titulo                 VARCHAR(150) NOT NULL,
  autor                  VARCHAR(100) NOT NULL,
  ejemplares_totales     INT NOT NULL CHECK (ejemplares_totales >= 0),
  ejemplares_disponibles INT NOT NULL CHECK (ejemplares_disponibles >= 0)
);

CREATE TABLE prestamos (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  socio_id         INT  NOT NULL,
  libro_id         INT  NOT NULL,
  fecha_prestamo   DATE NOT NULL,
  fecha_limite     DATE NOT NULL,
  fecha_devolucion DATE NULL,
  CONSTRAINT fk_prestamos_socio FOREIGN KEY (socio_id) REFERENCES socios(id),
  CONSTRAINT fk_prestamos_libro FOREIGN KEY (libro_id) REFERENCES libros(id)
);

CREATE TABLE historial_prestamos (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  prestamo_id INT          NOT NULL,
  accion      VARCHAR(20)  NOT NULL,
  detalle     VARCHAR(255),
  usuario     VARCHAR(100) NOT NULL,
  fecha       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_historial_prestamo FOREIGN KEY (prestamo_id) REFERENCES prestamos(id)
);


# 1) datos de prubea
INSERT INTO socios (nombre, email, activo) VALUES
  ('Camila Rojas', 'camila@correo.com', TRUE),
  ('Andrés Díaz', 'andres@correo.com', TRUE),
  ('Valentina Ríos','valentina@correo.com', FALSE),   # inactiva
  ('Mateo Castro',  'mateo@correo.com', TRUE);    # ya tiene 3 prestamos activos

INSERT INTO libros (titulo, autor, ejemplares_totales, ejemplares_disponibles) VALUES
  ('Cien años de soledad', 'Gabriel García Márquez', 3, 2),
  ('Clean Code', 'Robert C. Martin', 2, 0),   
  ('Fundamentos de bases de datos', 'Abraham Silberschatz', 4, 3),
  ('El principito', 'Antoine de Saint-Exupéry', 2, 2);

INSERT INTO prestamos (socio_id, libro_id, fecha_prestamo, fecha_limite, fecha_devolucion) VALUES
  (1, 1, CURRENT_DATE - INTERVAL '40' DAY, CURRENT_DATE - INTERVAL '26' DAY, CURRENT_DATE - INTERVAL '27' DAY), # devuelto
  (2, 2, CURRENT_DATE - INTERVAL '20' DAY, CURRENT_DATE - INTERVAL '6' DAY,  NULL),  # vencido hace 6 días
  (4, 2, CURRENT_DATE - INTERVAL '18' DAY, CURRENT_DATE - INTERVAL '4' DAY,  NULL),  # vencido hace 4 días
  (4, 1, CURRENT_DATE - INTERVAL '5' DAY,  CURRENT_DATE + INTERVAL '9' DAY,  NULL),  # al día
  (4, 3, CURRENT_DATE - INTERVAL '2' DAY,  CURRENT_DATE + INTERVAL '12' DAY, NULL);  # al día


# 2) R1 vista
CREATE OR REPLACE VIEW v_prestamos_vencidos AS
SELECT p.id AS prestamo_id,
       s.nombre AS socio,
       s.email AS email,
       l.titulo AS libro,
       p.fecha_limite AS fecha_limite,
       DATEDIFF(CURRENT_DATE, p.fecha_limite) AS dias_retraso
FROM prestamos p
JOIN socios s ON s.id = p.socio_id
JOIN libros l ON l.id = p.libro_id
WHERE p.fecha_devolucion IS NULL
  AND p.fecha_limite < CURRENT_DATE;

# 3) R2  procedimiento almacenado
DROP PROCEDURE IF EXISTS sp_prestar_libro;

DELIMITER //
CREATE PROCEDURE sp_prestar_libro(
  IN  p_socio_id INT,
  IN  p_libro_id INT,
  IN  p_dias INT,
  OUT p_prestamo_id INT
)
BEGIN
  DECLARE v_activo BOOLEAN;
  DECLARE v_activos INT;
  DECLARE v_disponibles INT;

#ante cualquier error se deshace todo y se relanza el error original
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;

  SET p_prestamo_id = NULL;

# entre 1 y 30 dias
  IF p_dias IS NULL OR p_dias < 1 OR p_dias > 30 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Días fuera de rango: el préstamo debe durar entre 1 y 30 días';
  END IF;

  START TRANSACTION;

#  socio activo (FOR UPDATE bloquea al socio y serializa sus prestamos simultaneos)
  SELECT activo INTO v_activo FROM socios WHERE id = p_socio_id FOR UPDATE;
  IF v_activo IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El socio no existe';
  END IF;
  IF v_activo = FALSE THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Socio inactivo: no puede recibir préstamos';
  END IF;

#maximo 3 prestamos activos
  SELECT COUNT(*) INTO v_activos
  FROM prestamos
  WHERE socio_id = p_socio_id AND fecha_devolucion IS NULL;
  IF v_activos >= 3 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El socio ya tiene 3 prestamos activos';
  END IF;

# ejemplares disponibles (FOR UPDATE evita que dos funcionarios presten a la vez el utimo ejemplar)
  SELECT ejemplares_disponibles INTO v_disponibles
  FROM libros WHERE id = p_libro_id FOR UPDATE;
  IF v_disponibles IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El libro no existe';
  END IF;
  IF v_disponibles < 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No hay ejemplares disponibles de este libro';
  END IF;

#Crear el prestamo
  INSERT INTO prestamos (socio_id, libro_id, fecha_prestamo, fecha_limite)
  VALUES (p_socio_id, p_libro_id, CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL p_dias DAY));
  SET p_prestamo_id = LAST_INSERT_ID();

#Descontar ejemplar
  UPDATE libros
  SET ejemplares_disponibles = ejemplares_disponibles - 1
  WHERE id = p_libro_id;

#Historial
  INSERT INTO historial_prestamos (prestamo_id, accion, detalle, usuario)
  VALUES (p_prestamo_id, 'PRESTAMO',
          CONCAT('Socio ', p_socio_id, ', libro ', p_libro_id, ', por ', p_dias, ' días'),
          CURRENT_USER());
  COMMIT;
END//
DELIMITER ;

# 4) trigger de devolucion

DROP TRIGGER IF EXISTS trg_prestamos_after_update_devolucion;

DELIMITER //
CREATE TRIGGER trg_prestamos_after_update_devolucion
AFTER UPDATE ON prestamos
FOR EACH ROW
BEGIN
  DECLARE v_retraso INT;

#Solo cuando pasa de "no devuelto" a "devuelto"
  IF OLD.fecha_devolucion IS NULL AND NEW.fecha_devolucion IS NOT NULL THEN
    SET v_retraso = GREATEST(DATEDIFF(NEW.fecha_devolucion, NEW.fecha_limite), 0);

    UPDATE libros
    SET ejemplares_disponibles = ejemplares_disponibles + 1
    WHERE id = NEW.libro_id;

    INSERT INTO historial_prestamos (prestamo_id, accion, detalle, usuario)
    VALUES (NEW.id, 'DEVOLUCION',
            CONCAT('Devuelto con ', v_retraso, ' días de retraso'),
            CURRENT_USER());
  END IF;
END//
DELIMITER ;

# no permitir fecha_devolucion anterior a fecha_prestamo
DROP TRIGGER IF EXISTS trg_prestamos_before_update_fechas;

DELIMITER //
CREATE TRIGGER trg_prestamos_before_update_fechas
BEFORE UPDATE ON prestamos
FOR EACH ROW
BEGIN
  IF NEW.fecha_devolucion IS NOT NULL AND NEW.fecha_devolucion < NEW.fecha_prestamo THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'La fecha de devolucion no puede ser anterior a la fecha de prestamo';
  END IF;
END//
DELIMITER ;

# 5) PRUEBAS (ejecutar UNA por UNA, en este orden)
# pruebas 3, 4, 5 y 6 deben dar error es lo esperado.

-- Prueba 1: 2 filas -> Andres (6 dias) y Mateo (4 dias)
SELECT * FROM v_prestamos_vencidos;

-- Prueba 2: prestamo id 6; El principito queda con 1 disponible
CALL sp_prestar_libro(1, 4, 14, @id);
SELECT @id AS prestamo_creado;
SELECT titulo, ejemplares_disponibles FROM libros WHERE id = 4;

-- Prueba 3: error socio inactivo
#CALL sp_prestar_libro(3, 1, 7, @id);	En comentario para no tener las errores en ejeccucion total

-- Prueba 4: error no hay ejemplares
#CALL sp_prestar_libro(1, 2, 7, @id);

-- Prueba 5: error ya tiene 3 préstamos activos
#CALL sp_prestar_libro(4, 1, 7, @id);

-- Prueba 6: error dias fuera de rango
#CALL sp_prestar_libro(1, 1, 0, @id);

-- Prueba 7: devolucion del prestamo 2 -> Clean Code a 1 disponible, DEVOLUCION con 6 dias
UPDATE prestamos SET fecha_devolucion = CURRENT_DATE WHERE id = 2;
SELECT titulo, ejemplares_disponibles FROM libros WHERE id = 2;
SELECT * FROM historial_prestamos ORDER BY id;

-- Prueba 8: solo queda Mateo
SELECT * FROM v_prestamos_vencidos;

-- Prueba 9: repetir el UPDATE de la prueba 7 -> nada cambia
UPDATE prestamos SET fecha_devolucion = CURRENT_DATE WHERE id = 2;
SELECT titulo, ejemplares_disponibles FROM libros WHERE id = 2;   -- sigue en 1
SELECT COUNT(*) AS filas_historial FROM historial_prestamos;      -- sin fila nueva


# PREGUNTAS DE ANALISIS
/*
1) La vista siempre muestra datos actuales; una tabla nocturna quedaria
desactualizada hasta 24 h y duplicaria datos. Usaria una vista
materializada (PostgreSQL) si la consulta fuera pesada y se tolerara
cierto desfase.

2)Procedimiento: recibe parametros, devuelve el id y es facil de
probar, pero se puede saltar con un INSERT directo.
Trigger se ejecuta siempre, pero es invisible y no recibe parametros.

3) Porque es un simple UPDATE que puede venir de cualquier sistema, el
trigger garantiza el inventario y el historial. Sin el, un UPDATE directo
dejaria el inventario incorrecto y sin registro.

4) Lo evita el FOR UPDATE sobre libros: el segundo espera, lee 0
disponibles y recibe el error.

5) Sin DELIMITER: cuerpo entre $$ ... $$; el trigger se divide en funcion + CREATE TRIGGER.
SIGNAL to RAISE EXCEPTION; DATEDIFF(a,b) to a - b; LAST_INSERT_ID() to RETURNING id INTO.
*/