-- he hecho sobre MY SQL 8.0

drop database if exists CicloVerde;
create database CicloVerde;
use CicloVerde;

-- SON LAS TABLAS -----------------------------------------------------------

CREATE TABLE estaciones (
    id_estacion INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    barrio VARCHAR(50) NOT NULL,
    capacidad INT NOT NULL,
    activa BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT pk_estaciones PRIMARY KEY (id_estacion),
    CONSTRAINT uk_esta_nombre UNIQUE (nombre),  
    CONSTRAINT chk_esta_cap CHECK (capacidad > 0)
);

CREATE TABLE bicicletas (
    id_bici INT NOT NULL AUTO_INCREMENT,
    codigo VARCHAR(10) NOT NULL,
    modelo VARCHAR(40) NOT NULL,
    estado VARCHAR(10) NOT NULL DEFAULT 'ACTIVA', -- Y LAS OTRAS SON EN LA CONSTRAINT MAS BAJA
    km_recorridos DECIMAL(7,1) NOT NULL DEFAULT 0,
    id_estacion INT NOT NULL,
    CONSTRAINT pk_bicicletas PRIMARY KEY (id_bici), -- PORQUE ESL LA PRIMARY KEY DE LA TABLA (VA A TENER LO MISMO POR LAS OTRAS TABLAS)
    CONSTRAINT uk_bicicletas_codigo UNIQUE(codigo),
    CONSTRAINT chk_bicicletas_estado CHECK (estado IN ('ACTIVA','TALLER','BAJA')),
    CONSTRAINT chk_bicicletas_km CHECK (km_recorridos >= 0),
    CONSTRAINT fk_bicicletas_estacion FOREIGN KEY (id_estacion)  -- PORQUE EN ESTE CASO LA id_estacioN ES UNA FOEIGN KEY
	REFERENCES estaciones (id_estacion) -- DEBE EXISTIR EN ESTACIONES
);

CREATE TABLE usuarios (
    id_usuario INT NOT NULL AUTO_INCREMENT,
    documento VARCHAR(15) NOT NULL,
    nombres VARCHAR(50) NOT NULL,
    apellidoS VARCHAR(50) NOT NULL,
    email VARCHAR(80) NULL,
    telefono VARCHAR(15) NULL,
    plan VARCHAR(10)  NOT NULL DEFAULT 'BASICO',
    fecha_registro DATE NOT NULL,
    id_referidor INT NULL,
    CONSTRAINT pk_usuarios PRIMARY KEY (id_usuario),
    CONSTRAINT uk_usuarios_documento UNIQUE (documento),
    CONSTRAINT uk_usuarios_email UNIQUE (email),
    CONSTRAINT chk_usuarios_plan CHECK (plan IN ('BASICO','PREMIUM'))
);

CREATE TABLE accesorios (
    id_accesorio INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(40) NOT NULL,
    precio DECIMAL(8,2) NOT NULL,
    CONSTRAINT pk_accesorios PRIMARY KEY (id_accesorio),
    CONSTRAINT uk_accesorios_nombre UNIQUE (nombre),
    CONSTRAINT chk_accesorios_precio CHECK (precio > 0)
);

CREATE TABLE viajes (
    id_viaje INT NOT NULL AUTO_INCREMENT,
    id_usuario INT NOT NULL,
    id_bici INT NOT NULL,
    id_estacion_origen INT NOT NULL,
    id_estacion_destino INT NULL,
    fecha_inicio DATETIME NOT NULL,
    fecha_fin DATETIME NULL,
    km DECIMAL(5,1) NOT NULL DEFAULT 0,
    estado VARCHAR(12) NOT NULL DEFAULT 'EN_CURSO',
    calificacion SMALLINT NULL,
    CONSTRAINT pk_viajes PRIMARY KEY (id_viaje),
    CONSTRAINT chk_viajes_km CHECK (km >= 0),
    CONSTRAINT chk_viajes_estado CHECK (estado IN ('EN_CURSO','FINALIZADO','CANCELADO')),
    CONSTRAINT chk_viajes_calif CHECK (calificacion BETWEEN 1 AND 5),
    CONSTRAINT fk_viajes_usuario FOREIGN KEY (id_usuario)  -- CONSTRAINT POR TODAS LAS FOREIGN KEYS QUE HAY EN ESTA TABLA
	REFERENCES usuarios (id_usuario),
    CONSTRAINT fk_viajes_bici FOREIGN KEY (id_bici)
	REFERENCES bicicletas (id_bici),
    CONSTRAINT fk_viajes_origen FOREIGN KEY (id_estacion_origen)
	REFERENCES estaciones (id_estacion),
    CONSTRAINT fk_viajes_destino FOREIGN KEY (id_estacion_destino)
	REFERENCES estaciones (id_estacion)
);

CREATE TABLE viaje_accesorio (
    id_viaje INT NOT NULL,
    id_accesorio INT NOT NULL,
    cantidad INT NOT NULL DEFAULT 1,
    CONSTRAINT pk_viaje_accesorio PRIMARY KEY (id_viaje, id_accesorio),  -- AQUI POR ESTA TABLA LA PRIM KEY SON LOS 2 PORQUE SON LOS ID DE LAS 2 OTRAS TABLAS DE ANTES 
    CONSTRAINT chk_viaje_acc_cant CHECK (cantidad > 0),
    CONSTRAINT fk_va_viaje FOREIGN KEY (id_viaje)	-- PERO LAS ID SON FOREIGN KEY PORQUE YA LOS TENEMOS EN UNA OTRA TABLAS DE ANTES
	REFERENCES viajes (id_viaje),
    CONSTRAINT fk_va_accesorio FOREIGN KEY (id_accesorio)
	REFERENCES accesorios (id_accesorio)
);

CREATE TABLE historial_bicicletas (
    id_historial INT NOT NULL AUTO_INCREMENT,
    id_bici INT NOT NULL,
    estado_anterior VARCHAR(10) NOT NULL,
    estado_nuevo VARCHAR(10) NOT NULL,
    fecha_cambio DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_historial PRIMARY KEY (id_historial),
    CONSTRAINT fk_historial_bici FOREIGN KEY (id_bici)
	REFERENCES bicicletas (id_bici)
);

-- =====================================================================
-- DATOS INICIALES — Operación Pedal (CicloVerde S.A.S.)
-- Ejecutar inmediatamente después del DDL de R2.
-- =====================================================================
INSERT INTO estaciones (id_estacion, nombre, barrio, capacidad, activa) VALUES
(1, 'Estación Las Aguas', 'La Candelaria', 12, TRUE),
(2, 'Estación Parque 93', 'Chapinero', 15, TRUE),
(3, 'Estación Usaquén', 'Usaquén', 10, TRUE),
(4, 'Estación Kennedy', 'Kennedy', 8, FALSE);
INSERT INTO bicicletas (id_bici, codigo, modelo, estado, km_recorridos, id_estacion)
VALUES
(1, 'CV-E01', 'Volta E2', 'ACTIVA', 1350.5, 1),
(2, 'CV-E02', 'Volta E2', 'ACTIVA', 820.0, 1),
(3, 'CV-M01', 'Urbana M1', 'ACTIVA', 240.0, 1),
(4, 'CV-E03', 'Volta E3', 'ACTIVA', 1620.0, 2),
(5, 'CV-M02', 'Urbana M1', 'TALLER', 95.5, 2),
(6, 'CV-E04', 'Volta E3', 'ACTIVA', 410.0, 3),
(7, 'CV-M03', 'Urbana M2', 'BAJA', 2100.0, 3),
(8, 'CV-E-PRO', 'Prototipo Volta X', 'ACTIVA', 60.0, 3);

-- Los usuarios que refieren se insertan antes que sus referidos.
INSERT INTO usuarios (id_usuario, documento, nombres, apellidos, email, telefono,
plan, fecha_registro, id_referidor) VALUES
(1, '1036101001', 'Valentina', 'Ríos Mejía', 'vale.rios@gmail.com',
'3001234567', 'PREMIUM', '2025-11-03', NULL),
(2, '1036101002', 'Santiago', 'Gómez Ruiz', 'sgomez@urosario.edu.co',
'3012223344', 'BASICO', '2026-01-15', 1),
(3, '1036101003', 'Isabella', 'Torres Cano', 'isa.torres@hotmail.com', NULL,
'PREMIUM', '2026-02-20', 1),
(4, '1036101004', 'Mateo', 'Herrera Díaz', NULL,
'312456789', 'BASICO', '2026-03-31', 2),
(5, '1036101005', 'Camila', 'Ortiz León', 'camila.ortiz@urosario.edu.co',
'3157654321', 'BASICO', '2026-05-10', NULL),
(6, '1036101006', 'Sebastián', 'Vargas Pino', 'sebas.vargas@gmail.com',
'3209876543', 'PREMIUM', '2026-07-01', 3),
(7, '1036101007', 'Daniela', 'Cruz Mora', 'DCRUZ@UROSARIO.EDU.CO',
'3104445566', 'BASICO', '2026-09-12', NULL),
(8, '1036101008', 'Andrés', 'Patiño Gil', NULL, NULL,
'BASICO', '2026-10-01', 5);
INSERT INTO accesorios (id_accesorio, nombre, precio) VALUES
(1, 'Casco', 2500),
(2, 'Candado', 1500),
(3, 'Canasta', 1000),
(4, 'Luz recargable', 2000);
INSERT INTO viajes (id_viaje, id_usuario, id_bici, id_estacion_origen,
id_estacion_destino, fecha_inicio, fecha_fin, km, estado, calificacion) VALUES
(1, 1, 1, 1, 2, '2026-10-01 07:10:00', '2026-10-01 07:32:00', 5.2, 'FINALIZADO',
5),
(2, 2, 3, 1, 3, '2026-10-01 08:00:00', '2026-10-01 08:25:00', 3.8, 'FINALIZADO',
4),
(3, 3, 4, 2, 1, '2026-10-02 18:05:00', '2026-10-02 18:40:00', 6.0, 'FINALIZADO',
2),
(4, 1, 2, 1, 1, '2026-10-03 12:00:00', '2026-10-03 12:15:00', 2.1, 'FINALIZADO',
NULL),
(5, 3, 6, 3, 2, '2026-10-04 09:30:00', '2026-10-04 09:58:00', 4.4, 'FINALIZADO',
3),
(6, 5, 1, 2, NULL, '2026-10-05 10:00:00', NULL, 0.0, 'CANCELADO',
NULL),
(7, 6, 4, 2, 3, '2026-10-06 17:20:00', '2026-10-06 18:05:00', 11.0, 'FINALIZADO',
5),
(8, 2, 2, 1, 2, '2026-10-08 07:45:00', '2026-10-08 08:05:00', 4.9, 'FINALIZADO',
1),
(9, 3, 6, 3, NULL, '2026-10-09 14:00:00', NULL, 0.8, 'CANCELADO',
NULL),
(10, 1, 6, 3, 1, '2026-10-11 06:50:00', '2026-10-11 07:20:00', 6.0, 'FINALIZADO',
4),
(11, 5, 3, 1, 3, '2026-10-12 16:00:00', '2026-10-12 16:18:00', 2.7, 'FINALIZADO',
5),
(12, 6, 8, 3, NULL, '2026-10-14 11:00:00', NULL, 0.0, 'CANCELADO',
NULL),
(13, 4, 2, 1, NULL, '2026-10-15 19:30:00', NULL, 1.2, 'EN_CURSO',
NULL), (14, 2, 6, 3, NULL, '2026-10-15 19:45:00', NULL, 0.0, 'EN_CURSO',
NULL);
INSERT INTO viaje_accesorio (id_viaje, id_accesorio, cantidad) VALUES
(1, 1, 1), (1, 2, 1),
(3, 1, 1),
(5, 3, 1),
(7, 1, 1), (7, 3, 1),
(8, 2, 1),
(10, 1, 1),
(11, 2, 1),
(13, 1, 1);


-- R3 : ALTER TABLE ---------------------------------------------------------
ALTER TABLE usuarios
    ADD CONSTRAINT fk_usuarios_referidor FOREIGN KEY (id_referidor)  -- YO AGREGE LA FOREING KEY DE LA CONSIGNA PARA VERIF QUE ES UN USUARIO EXISTANTE
	REFERENCES usuarios (id_usuario);

ALTER TABLE viajes		-- TAMBIEN UNA OTRA PARA EL CASO O ES NULA O NO ES ANTERIOR AL INICIO
    ADD CONSTRAINT chk_viajes_fechas
	CHECK (fecha_fin IS NULL OR fecha_fin >= fecha_inicio);
    
    
-- R4 ---------------------------------------------------------------------------------------------------------    
INSERT INTO usuarios (documento, nombres, apellidos, email, telefono, plan, fecha_registro, id_referidor) VALUES 
('1036101009', 'Lucía', 'Arango Vélez', 'lucia.arango@gmail.com','3165551234', 'PREMIUM', '2026-10-14', 2),
('1036101010', 'Juan Pablo', 'Restrepo Sierra', 'jp.restrepo@unal.edu.co','3001112222', 'BASICO', '2026-10-15', NULL);

SET SQL_SAFE_UPDATES = 0; -- PORQUE SINO TENIA UN PROBLEMA DE ERROR 1175 QUE ME DIJO QUE USO EL SAFE UPDATE MODE (YO VI ESO EN UN ENTRETAMIENTO)

-- B
UPDATE bicicletas SET estado = 'TALLER' -- PORQUE "Toda bicicleta ACTIVA con más de 1.500 km debe pasar a TALLER"
WHERE estado = 'ACTIVA' AND km_recorridos > 1500;

-- C 
DELETE FROM viajes
WHERE estado = 'CANCELADO' AND km = 0;

-- D
SELECT		-- SELECT DE SELECT PARA VER TODOS EN UNA SOLA VEZ
	(SELECT COUNT(*) FROM usuarios) AS usuarios,
    (SELECT COUNT(*) FROM viajes) AS viajes,
    (SELECT COUNT(*) FROM bicicletas WHERE estado = 'TALLER') AS bicis_en_taller;


-- R5 ------------------------------------------------------------------------------------------------------------------------------------------------------------------
SELECT id_viaje, id_estacion_origen, km, calificacion FROM viajes 
WHERE estado = 'FINALIZADO' AND (km BETWEEN 2 AND 6) AND (id_estacion_origen IN (1, 2))
ORDER BY km DESC;

-- B
SELECT codigo, modelo, estado, km_recorridos FROM bicicletas
WHERE estado != 'BAJA' AND (km_recorridos < 300 OR km_recorridos >= 1200)
ORDER BY codigo ASC;

-- C
SELECT id_viaje, id_usuario, estado, fecha_inicio FROM viajes
WHERE fecha_fin IS NULL AND estado NOT IN ('CANCELADO')
ORDER BY fecha_inicio;

-- D
SELECT nombres, apellidos, plan, fecha_registro FROM usuarios
WHERE NOT plan = 'PREMIUM' AND fecha_registro <= '2026-03-31'
ORDER BY fecha_registro ASC;

-- R6 ------------------------------------------------------------------------------------------------------
SELECT CONCAT(nombres, ' ', apellidos) AS usuario, LOWER(email) AS correo FROM usuarios
WHERE email IS NOT NULL AND LOWER(email) NOT LIKE '%@gmail.com' AND LOWER(email) NOT LIKE '%@hotmail.com'
ORDER BY usuario;

-- B 
SELECT codigo, UPPER(modelo) AS modelo, km_recorridos, ROUND(km_recorridos / 1500 * 100, 1) AS pct_revision FROM bicicletas
WHERE codigo LIKE 'CV-E__'
ORDER BY km_recorridos DESC;


